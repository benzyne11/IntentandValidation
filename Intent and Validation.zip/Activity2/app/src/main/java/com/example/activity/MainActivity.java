package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
// Group 2 : Leslie Benzyne T. Viluan
//           Mary Christine Cas
public class MainActivity extends AppCompatActivity {
    private EditText myname, mypass;
    private Button clk;

    
    boolean isValid = false;
    private String use = "Moriii";
    private String pass1 = "123";
    private String use2 = "lunox";
    private String pass2 = "1234";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myname = (EditText) findViewById(R.id.name);
        mypass = (EditText) findViewById((R.id.pass));
        clk = (Button) findViewById(R.id.button);
        clk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stname = myname.getText().toString();
                String stpass = mypass.getText().toString();

                if(stname.isEmpty() || stpass.isEmpty()){
                    Toast.makeText(MainActivity.this, "Required", Toast.LENGTH_SHORT).show();
                }else{

                    isValid = validate(stname,stpass);
                    isValid = validate1(stname,stpass);


                    if(stname.equals(use) && stpass.equals(pass1)){

                        //dashboard activity 1
                        Intent intent = new Intent(MainActivity.this, dashboard.class);
                        startActivity(intent);
                        finish();
                    }else if(stname.equals(use2) && stpass.equals(pass2)){

                        //dashboard activity 2
                        Intent intent = new Intent(MainActivity.this, dashboard2.class);
                        startActivity(intent);
                        finish();

                    }else if(!isValid){
                        Toast.makeText(MainActivity.this, "Wrong", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    //function to validate the input
    private boolean validate(String name, String password){
        if(name.equals(use) && password.equals(pass1)){
            return true;
        }
        return false;
    }

    private boolean validate1(String name, String password){
        if(name.equals(use2) && password.equals(pass2)){
            return true;
        }
        return false;
    }